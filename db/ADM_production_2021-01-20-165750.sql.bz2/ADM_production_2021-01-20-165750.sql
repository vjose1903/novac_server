--
-- PostgreSQL database dump
--

-- Dumped from database version 13.0
-- Dumped by pg_dump version 13.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: articulos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.articulos (
    id bigint NOT NULL,
    imagen_id bigint,
    tipo_articulo_id bigint,
    nombre character varying,
    costo_principal double precision,
    precio_principal double precision,
    existencia double precision,
    aviso_existencia integer,
    codigo character varying,
    fecha_ingreso date,
    medida character varying,
    is_detallable boolean,
    medida_alerta character varying,
    calcular_itbis boolean,
    estado boolean,
    is_combo boolean,
    otros_costos double precision,
    vendido_en character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_materia_prima boolean,
    calcular_saco boolean
);


--
-- Name: articulos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.articulos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: articulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.articulos_id_seq OWNED BY public.articulos.id;


--
-- Name: cabecera_conduces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cabecera_conduces (
    id bigint NOT NULL,
    user_id bigint,
    cliente_id bigint,
    numero_conduce integer,
    fecha_equivalente timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cabecera_conduces_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cabecera_conduces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cabecera_conduces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cabecera_conduces_id_seq OWNED BY public.cabecera_conduces.id;


--
-- Name: cabecera_facturas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cabecera_facturas (
    id bigint NOT NULL,
    tipo_factura_id bigint,
    suplidor_id bigint,
    cliente_id bigint,
    user_id bigint,
    fecha_viaje timestamp without time zone,
    fecha_equivalente timestamp without time zone,
    fecha_vencimiento timestamp without time zone,
    fecha_valida timestamp without time zone,
    fecha_completada timestamp without time zone,
    numero_comprobante character varying,
    numero_factura integer,
    condicion character varying,
    forma_pago character varying,
    total_factura double precision,
    itbis double precision,
    descuento double precision,
    "Bruto" double precision,
    estado boolean,
    tipo character varying,
    "NoCliente_nombre" character varying,
    "NoCliente_direccion" character varying,
    "costoYgasto" character varying,
    pagada boolean,
    vendedor_id integer,
    balance double precision,
    devuelta double precision,
    is_adelantada boolean,
    is_nota boolean,
    is_viaje boolean,
    tiene_nota boolean,
    aplicada_a character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cabecera_facturas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cabecera_facturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cabecera_facturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cabecera_facturas_id_seq OWNED BY public.cabecera_facturas.id;


--
-- Name: clientes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clientes (
    id bigint NOT NULL,
    imagen_id bigint,
    nombre character varying,
    apellido character varying,
    telefono character varying,
    direccion character varying,
    limite_credito integer,
    sexo character varying(1),
    estado boolean,
    maximo_credito double precision,
    vendedor_id integer,
    balance double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.clientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: contenido_articulos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contenido_articulos (
    id bigint NOT NULL,
    articulo_id bigint,
    referencia integer,
    costo double precision,
    precio double precision,
    cantidad integer,
    medida character varying,
    condicion character varying,
    calcular_itbis boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: contenido_articulos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contenido_articulos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contenido_articulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contenido_articulos_id_seq OWNED BY public.contenido_articulos.id;


--
-- Name: cuadre_cajas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cuadre_cajas (
    id bigint NOT NULL,
    user_id bigint,
    total_general double precision,
    total_venta_credito double precision,
    total_venta_contado double precision,
    total_recibo_ingreso double precision,
    total_anterior double precision,
    numero_reporte integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: cuadre_cajas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cuadre_cajas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cuadre_cajas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cuadre_cajas_id_seq OWNED BY public.cuadre_cajas.id;


--
-- Name: detalle_conduces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detalle_conduces (
    id bigint NOT NULL,
    cabecera_conduce_id bigint,
    detalle_factura_id bigint,
    articulo_id bigint,
    cantidad double precision,
    cantidad_en_unidades integer,
    unidad character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: detalle_conduces_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.detalle_conduces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: detalle_conduces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.detalle_conduces_id_seq OWNED BY public.detalle_conduces.id;


--
-- Name: detalle_facturas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detalle_facturas (
    id bigint NOT NULL,
    cabecera_factura_id bigint,
    articulo_id bigint,
    unidad character varying,
    total double precision,
    cantidad double precision,
    cantidad_en_unidades integer,
    itbis double precision,
    precio double precision,
    costo double precision,
    retirado integer,
    retirado_en_venta integer,
    descuento_valor double precision,
    descuento_porciento double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    calcular_saco boolean,
    detalle_factura_nota integer
);


--
-- Name: detalle_facturas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.detalle_facturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: detalle_facturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.detalle_facturas_id_seq OWNED BY public.detalle_facturas.id;


--
-- Name: detalle_recibos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detalle_recibos (
    id bigint NOT NULL,
    recibos_ingreso_id bigint,
    cabecera_factura_id bigint,
    balance_factura double precision,
    balance_anterior_factura double precision,
    pago_total boolean,
    deposito double precision,
    descripcion character varying,
    pago_a_tiempo boolean,
    is_ultimo boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: detalle_recibos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.detalle_recibos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: detalle_recibos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.detalle_recibos_id_seq OWNED BY public.detalle_recibos.id;


--
-- Name: detalles_produccion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.detalles_produccion (
    id bigint NOT NULL,
    produccion_id bigint,
    articulo_id bigint,
    cantidad double precision,
    cantidad_en_unidades integer,
    medida character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: detalles_produccion_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.detalles_produccion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: detalles_produccion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.detalles_produccion_id_seq OWNED BY public.detalles_produccion.id;


--
-- Name: documentos_de_identidad; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documentos_de_identidad (
    id bigint NOT NULL,
    user_id bigint,
    cliente_id bigint,
    suplidor_id bigint,
    descripcion character varying,
    documento character varying,
    principal boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: documentos_de_identidad_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documentos_de_identidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documentos_de_identidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documentos_de_identidad_id_seq OWNED BY public.documentos_de_identidad.id;


--
-- Name: formulas_productos_terminados; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.formulas_productos_terminados (
    id bigint NOT NULL,
    articulo_id bigint,
    cantidad double precision,
    costo double precision,
    articulo_combo integer,
    precio double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: formulas_productos_terminados_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.formulas_productos_terminados_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: formulas_productos_terminados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.formulas_productos_terminados_id_seq OWNED BY public.formulas_productos_terminados.id;


--
-- Name: historico_producciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historico_producciones (
    id bigint NOT NULL,
    user_id bigint,
    articulo_id bigint,
    cantidad double precision,
    medida character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: historico_producciones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.historico_producciones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: historico_producciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.historico_producciones_id_seq OWNED BY public.historico_producciones.id;


--
-- Name: imagenes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.imagenes (
    id bigint NOT NULL,
    file_name character varying,
    base_64 character varying,
    path character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: imagenes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.imagenes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: imagenes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.imagenes_id_seq OWNED BY public.imagenes.id;


--
-- Name: incidencias; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.incidencias (
    id bigint NOT NULL,
    referencia integer,
    descripcion character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: incidencias_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.incidencias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incidencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.incidencias_id_seq OWNED BY public.incidencias.id;


--
-- Name: mantenimiento_articulos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mantenimiento_articulos (
    id bigint NOT NULL,
    articulo_id bigint,
    user_id bigint,
    ant_nombre character varying,
    ant_medida character varying,
    "ant_costoP" double precision,
    "ant_precioP" double precision,
    "ant_alertaExistencia" integer,
    "ant_isDetallable" boolean,
    "ant_medidaPadre" character varying,
    "ant_costoPadre" double precision,
    "ant_precioPadre" double precision,
    "ant_cantidadPadre" integer,
    "ant_medidaHijo" character varying,
    "ant_costoHijo" double precision,
    "ant_precioHijo" double precision,
    "ant_cantidadHijo" integer,
    "ant_medidaAlerta" character varying,
    vendido_en character varying,
    "ant_idPadre" integer,
    "ant_idHijo" integer,
    "ant_referenciaPadre" integer,
    "ant_referenciaHijo" integer,
    "ant_tipoArticuloId" integer,
    "ant_isCombo" boolean,
    "ant_calcularItbis" boolean,
    "ant_otrosCostos" double precision,
    secuencia integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    is_materia_prima boolean,
    calcular_saco boolean
);


--
-- Name: mantenimiento_articulos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mantenimiento_articulos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mantenimiento_articulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mantenimiento_articulos_id_seq OWNED BY public.mantenimiento_articulos.id;


--
-- Name: mantenimiento_formulas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mantenimiento_formulas (
    id bigint NOT NULL,
    articulo_id integer,
    cantidad double precision,
    costo double precision,
    secuencia integer,
    articulo_combo integer,
    precio double precision,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: mantenimiento_formulas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mantenimiento_formulas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mantenimiento_formulas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mantenimiento_formulas_id_seq OWNED BY public.mantenimiento_formulas.id;


--
-- Name: marcas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marcas (
    id bigint NOT NULL,
    descripcion character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: marcas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.marcas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marcas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.marcas_id_seq OWNED BY public.marcas.id;


--
-- Name: modelos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.modelos (
    id bigint NOT NULL,
    marca_id bigint,
    descripcion character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: modelos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.modelos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: modelos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.modelos_id_seq OWNED BY public.modelos.id;


--
-- Name: movimientos_inventarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.movimientos_inventarios (
    id bigint NOT NULL,
    user_id bigint,
    articulo_id bigint,
    cantidad double precision,
    accion character varying,
    motivo character varying,
    medida character varying,
    tipo_salida character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: movimientos_inventarios_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.movimientos_inventarios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: movimientos_inventarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.movimientos_inventarios_id_seq OWNED BY public.movimientos_inventarios.id;


--
-- Name: producciones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.producciones (
    id bigint NOT NULL,
    user_id bigint,
    numero integer,
    fecha_equivalente timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: producciones_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.producciones_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: producciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.producciones_id_seq OWNED BY public.producciones.id;


--
-- Name: recibos_ingresos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recibos_ingresos (
    id bigint NOT NULL,
    user_id bigint,
    tipo_factura_id bigint,
    cliente_id bigint,
    vehiculo_id bigint,
    total double precision,
    chofer integer,
    forma_pago character varying,
    numero_recibo integer,
    incidencia integer,
    devuelta double precision,
    fecha_equivalente timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: recibos_ingresos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recibos_ingresos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recibos_ingresos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recibos_ingresos_id_seq OWNED BY public.recibos_ingresos.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: secuencia_comprobantes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secuencia_comprobantes (
    id bigint NOT NULL,
    tipo_factura_id bigint,
    secuencia bigint,
    desde bigint,
    hasta bigint,
    fecha_compra timestamp without time zone,
    fecha_valida timestamp without time zone,
    estado boolean,
    usado boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    referencia character varying
);


--
-- Name: secuencia_comprobantes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.secuencia_comprobantes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: secuencia_comprobantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.secuencia_comprobantes_id_seq OWNED BY public.secuencia_comprobantes.id;


--
-- Name: secuencia_facturas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.secuencia_facturas (
    id bigint NOT NULL,
    tipo_factura_id bigint,
    secuencia integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: secuencia_facturas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.secuencia_facturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: secuencia_facturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.secuencia_facturas_id_seq OWNED BY public.secuencia_facturas.id;


--
-- Name: suplidores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suplidores (
    id bigint NOT NULL,
    nombre character varying,
    telefono character varying,
    direccion character varying,
    email character varying,
    estado boolean,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: suplidores_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.suplidores_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: suplidores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.suplidores_id_seq OWNED BY public.suplidores.id;


--
-- Name: tipo_articulos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tipo_articulos (
    id bigint NOT NULL,
    descripcion text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: tipo_articulos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tipo_articulos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tipo_articulos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tipo_articulos_id_seq OWNED BY public.tipo_articulos.id;


--
-- Name: tipo_facturas; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tipo_facturas (
    id bigint NOT NULL,
    referencia character varying,
    descripcion character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: tipo_facturas_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tipo_facturas_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tipo_facturas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tipo_facturas_id_seq OWNED BY public.tipo_facturas.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    provider character varying DEFAULT 'email'::character varying NOT NULL,
    uid character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp without time zone,
    allow_password_change boolean DEFAULT false,
    remember_created_at timestamp without time zone,
    confirmation_token character varying,
    confirmed_at timestamp without time zone,
    confirmation_sent_at timestamp without time zone,
    unconfirmed_email character varying,
    sign_in_count integer DEFAULT 0 NOT NULL,
    current_sign_in_at timestamp without time zone,
    last_sign_in_at timestamp without time zone,
    current_sign_in_ip character varying,
    last_sign_in_ip character varying,
    imagen_id bigint,
    nombre character varying,
    usuario character varying,
    apellido character varying,
    sexo character varying,
    telefono character varying,
    email character varying,
    fecha_nacimiento character varying,
    estado boolean,
    role character varying,
    tokens json,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehiculos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vehiculos (
    id bigint NOT NULL,
    user_id bigint,
    marca character varying,
    modelo character varying,
    cantidad_viajes integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    nombre_no_empleado character varying,
    apellido_no_empleado character varying,
    telefono_no_empleado character varying,
    anio character varying,
    estado boolean
);


--
-- Name: vehiculos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.vehiculos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: vehiculos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.vehiculos_id_seq OWNED BY public.vehiculos.id;


--
-- Name: articulos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articulos ALTER COLUMN id SET DEFAULT nextval('public.articulos_id_seq'::regclass);


--
-- Name: cabecera_conduces id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_conduces ALTER COLUMN id SET DEFAULT nextval('public.cabecera_conduces_id_seq'::regclass);


--
-- Name: cabecera_facturas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_facturas ALTER COLUMN id SET DEFAULT nextval('public.cabecera_facturas_id_seq'::regclass);


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: contenido_articulos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contenido_articulos ALTER COLUMN id SET DEFAULT nextval('public.contenido_articulos_id_seq'::regclass);


--
-- Name: cuadre_cajas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cuadre_cajas ALTER COLUMN id SET DEFAULT nextval('public.cuadre_cajas_id_seq'::regclass);


--
-- Name: detalle_conduces id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_conduces ALTER COLUMN id SET DEFAULT nextval('public.detalle_conduces_id_seq'::regclass);


--
-- Name: detalle_facturas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_facturas ALTER COLUMN id SET DEFAULT nextval('public.detalle_facturas_id_seq'::regclass);


--
-- Name: detalle_recibos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_recibos ALTER COLUMN id SET DEFAULT nextval('public.detalle_recibos_id_seq'::regclass);


--
-- Name: detalles_produccion id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_produccion ALTER COLUMN id SET DEFAULT nextval('public.detalles_produccion_id_seq'::regclass);


--
-- Name: documentos_de_identidad id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_de_identidad ALTER COLUMN id SET DEFAULT nextval('public.documentos_de_identidad_id_seq'::regclass);


--
-- Name: formulas_productos_terminados id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.formulas_productos_terminados ALTER COLUMN id SET DEFAULT nextval('public.formulas_productos_terminados_id_seq'::regclass);


--
-- Name: historico_producciones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historico_producciones ALTER COLUMN id SET DEFAULT nextval('public.historico_producciones_id_seq'::regclass);


--
-- Name: imagenes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imagenes ALTER COLUMN id SET DEFAULT nextval('public.imagenes_id_seq'::regclass);


--
-- Name: incidencias id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidencias ALTER COLUMN id SET DEFAULT nextval('public.incidencias_id_seq'::regclass);


--
-- Name: mantenimiento_articulos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mantenimiento_articulos ALTER COLUMN id SET DEFAULT nextval('public.mantenimiento_articulos_id_seq'::regclass);


--
-- Name: mantenimiento_formulas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mantenimiento_formulas ALTER COLUMN id SET DEFAULT nextval('public.mantenimiento_formulas_id_seq'::regclass);


--
-- Name: marcas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marcas ALTER COLUMN id SET DEFAULT nextval('public.marcas_id_seq'::regclass);


--
-- Name: modelos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modelos ALTER COLUMN id SET DEFAULT nextval('public.modelos_id_seq'::regclass);


--
-- Name: movimientos_inventarios id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_inventarios ALTER COLUMN id SET DEFAULT nextval('public.movimientos_inventarios_id_seq'::regclass);


--
-- Name: producciones id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.producciones ALTER COLUMN id SET DEFAULT nextval('public.producciones_id_seq'::regclass);


--
-- Name: recibos_ingresos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recibos_ingresos ALTER COLUMN id SET DEFAULT nextval('public.recibos_ingresos_id_seq'::regclass);


--
-- Name: secuencia_comprobantes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secuencia_comprobantes ALTER COLUMN id SET DEFAULT nextval('public.secuencia_comprobantes_id_seq'::regclass);


--
-- Name: secuencia_facturas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secuencia_facturas ALTER COLUMN id SET DEFAULT nextval('public.secuencia_facturas_id_seq'::regclass);


--
-- Name: suplidores id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suplidores ALTER COLUMN id SET DEFAULT nextval('public.suplidores_id_seq'::regclass);


--
-- Name: tipo_articulos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipo_articulos ALTER COLUMN id SET DEFAULT nextval('public.tipo_articulos_id_seq'::regclass);


--
-- Name: tipo_facturas id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipo_facturas ALTER COLUMN id SET DEFAULT nextval('public.tipo_facturas_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehiculos id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehiculos ALTER COLUMN id SET DEFAULT nextval('public.vehiculos_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2021-01-19 11:22:19.070088	2021-01-19 11:22:19.070088
\.


--
-- Data for Name: articulos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.articulos (id, imagen_id, tipo_articulo_id, nombre, costo_principal, precio_principal, existencia, aviso_existencia, codigo, fecha_ingreso, medida, is_detallable, medida_alerta, calcular_itbis, estado, is_combo, otros_costos, vendido_en, created_at, updated_at, is_materia_prima, calcular_saco) FROM stdin;
\.


--
-- Data for Name: cabecera_conduces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cabecera_conduces (id, user_id, cliente_id, numero_conduce, fecha_equivalente, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cabecera_facturas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cabecera_facturas (id, tipo_factura_id, suplidor_id, cliente_id, user_id, fecha_viaje, fecha_equivalente, fecha_vencimiento, fecha_valida, fecha_completada, numero_comprobante, numero_factura, condicion, forma_pago, total_factura, itbis, descuento, "Bruto", estado, tipo, "NoCliente_nombre", "NoCliente_direccion", "costoYgasto", pagada, vendedor_id, balance, devuelta, is_adelantada, is_nota, is_viaje, tiene_nota, aplicada_a, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clientes (id, imagen_id, nombre, apellido, telefono, direccion, limite_credito, sexo, estado, maximo_credito, vendedor_id, balance, created_at, updated_at) FROM stdin;
1	\N	Cliente contado	\N	\N	Autopista duarte KM 0 el Higuero	\N	\N	\N	\N	\N	\N	2021-01-19 11:22:19.661964	2021-01-19 11:22:19.661964
\.


--
-- Data for Name: contenido_articulos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contenido_articulos (id, articulo_id, referencia, costo, precio, cantidad, medida, condicion, calcular_itbis, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cuadre_cajas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cuadre_cajas (id, user_id, total_general, total_venta_credito, total_venta_contado, total_recibo_ingreso, total_anterior, numero_reporte, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: detalle_conduces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detalle_conduces (id, cabecera_conduce_id, detalle_factura_id, articulo_id, cantidad, cantidad_en_unidades, unidad, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: detalle_facturas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detalle_facturas (id, cabecera_factura_id, articulo_id, unidad, total, cantidad, cantidad_en_unidades, itbis, precio, costo, retirado, retirado_en_venta, descuento_valor, descuento_porciento, created_at, updated_at, calcular_saco, detalle_factura_nota) FROM stdin;
\.


--
-- Data for Name: detalle_recibos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detalle_recibos (id, recibos_ingreso_id, cabecera_factura_id, balance_factura, balance_anterior_factura, pago_total, deposito, descripcion, pago_a_tiempo, is_ultimo, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: detalles_produccion; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.detalles_produccion (id, produccion_id, articulo_id, cantidad, cantidad_en_unidades, medida, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: documentos_de_identidad; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documentos_de_identidad (id, user_id, cliente_id, suplidor_id, descripcion, documento, principal, created_at, updated_at) FROM stdin;
1	1	\N	\N	cedula	402-1463928-4	t	2021-01-19 11:22:19.680629	2021-01-19 11:22:19.680629
2	\N	1	\N	cedula	 	t	2021-01-19 11:22:19.684867	2021-01-19 11:22:19.684867
\.


--
-- Data for Name: formulas_productos_terminados; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.formulas_productos_terminados (id, articulo_id, cantidad, costo, articulo_combo, precio, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: historico_producciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.historico_producciones (id, user_id, articulo_id, cantidad, medida, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: imagenes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.imagenes (id, file_name, base_64, path, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incidencias; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.incidencias (id, referencia, descripcion, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: mantenimiento_articulos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mantenimiento_articulos (id, articulo_id, user_id, ant_nombre, ant_medida, "ant_costoP", "ant_precioP", "ant_alertaExistencia", "ant_isDetallable", "ant_medidaPadre", "ant_costoPadre", "ant_precioPadre", "ant_cantidadPadre", "ant_medidaHijo", "ant_costoHijo", "ant_precioHijo", "ant_cantidadHijo", "ant_medidaAlerta", vendido_en, "ant_idPadre", "ant_idHijo", "ant_referenciaPadre", "ant_referenciaHijo", "ant_tipoArticuloId", "ant_isCombo", "ant_calcularItbis", "ant_otrosCostos", secuencia, created_at, updated_at, is_materia_prima, calcular_saco) FROM stdin;
\.


--
-- Data for Name: mantenimiento_formulas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mantenimiento_formulas (id, articulo_id, cantidad, costo, secuencia, articulo_combo, precio, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: marcas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marcas (id, descripcion, created_at, updated_at) FROM stdin;
1	Daihatsu	2021-01-19 11:22:19.846365	2021-01-19 11:22:19.846365
\.


--
-- Data for Name: modelos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.modelos (id, marca_id, descripcion, created_at, updated_at) FROM stdin;
1	1	Delta	2021-01-19 11:22:19.860573	2021-01-19 11:22:19.860573
\.


--
-- Data for Name: movimientos_inventarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.movimientos_inventarios (id, user_id, articulo_id, cantidad, accion, motivo, medida, tipo_salida, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: producciones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.producciones (id, user_id, numero, fecha_equivalente, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recibos_ingresos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recibos_ingresos (id, user_id, tipo_factura_id, cliente_id, vehiculo_id, total, chofer, forma_pago, numero_recibo, incidencia, devuelta, fecha_equivalente, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
20191003033636
20191003033638
20191013133738
20191013140032
20191013140033
20191013140441
20191030125115
20191117165659
20191117170939
20191117172103
20191117172554
20191224140054
20200104030722
20200104124804
20200107112359
20200114125442
20200114125445
20200115121826
20200115122854
20200305203246
20200311150257
20200623130720
20200623130726
20201006190104
20201006190449
20201024105524
20201103112406
20201113195318
20201114114301
20201114114313
20201115125356
20201115150043
20201120012445
20201122122154
20201209121324
20201209134003
20201217000114
\.


--
-- Data for Name: secuencia_comprobantes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.secuencia_comprobantes (id, tipo_factura_id, secuencia, desde, hasta, fecha_compra, fecha_valida, estado, usado, created_at, updated_at, referencia) FROM stdin;
1	1	1	1	9223372036854775807	2021-01-19 11:22:19.816842	\N	t	f	2021-01-19 11:22:19.832287	2021-01-19 11:22:19.832287	\N
2	3	1	1	9223372036854775807	2021-01-19 11:22:19.816843	\N	t	f	2021-01-19 11:22:19.836074	2021-01-19 11:22:19.836074	\N
\.


--
-- Data for Name: secuencia_facturas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.secuencia_facturas (id, tipo_factura_id, secuencia, created_at, updated_at) FROM stdin;
1	1	0	2021-01-19 11:22:19.741893	2021-01-19 11:22:19.741893
2	2	0	2021-01-19 11:22:19.748095	2021-01-19 11:22:19.748095
3	3	0	2021-01-19 11:22:19.753063	2021-01-19 11:22:19.753063
4	4	0	2021-01-19 11:22:19.757539	2021-01-19 11:22:19.757539
5	5	0	2021-01-19 11:22:19.762222	2021-01-19 11:22:19.762222
6	6	0	2021-01-19 11:22:19.767052	2021-01-19 11:22:19.767052
7	7	0	2021-01-19 11:22:19.771485	2021-01-19 11:22:19.771485
8	8	0	2021-01-19 11:22:19.775599	2021-01-19 11:22:19.775599
9	9	0	2021-01-19 11:22:19.780295	2021-01-19 11:22:19.780295
10	10	0	2021-01-19 11:22:19.784712	2021-01-19 11:22:19.784712
11	11	0	2021-01-19 11:22:19.789276	2021-01-19 11:22:19.789276
12	12	0	2021-01-19 11:22:19.793411	2021-01-19 11:22:19.793411
13	13	0	2021-01-19 11:22:19.798773	2021-01-19 11:22:19.798773
14	14	0	2021-01-19 11:22:19.803095	2021-01-19 11:22:19.803095
15	15	0	2021-01-19 11:22:19.807162	2021-01-19 11:22:19.807162
16	16	0	2021-01-19 11:22:19.811194	2021-01-19 11:22:19.811194
17	17	0	2021-01-19 11:22:19.815659	2021-01-19 11:22:19.815659
\.


--
-- Data for Name: suplidores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suplidores (id, nombre, telefono, direccion, email, estado, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tipo_articulos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tipo_articulos (id, descripcion, created_at, updated_at) FROM stdin;
1	Veterinaria	2021-01-19 11:22:19.694602	2021-01-19 11:22:19.694602
2	Materia prima	2021-01-19 11:22:19.697606	2021-01-19 11:22:19.697606
3	Producto terminado	2021-01-19 11:22:19.699807	2021-01-19 11:22:19.699807
4	Otros	2021-01-19 11:22:19.701861	2021-01-19 11:22:19.701861
\.


--
-- Data for Name: tipo_facturas; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tipo_facturas (id, referencia, descripcion, created_at, updated_at) FROM stdin;
1	00	Factura sin comprobante	2021-01-19 11:22:19.711725	2021-01-19 11:22:19.711725
2	01	Factura con valor fiscal	2021-01-19 11:22:19.745076	2021-01-19 11:22:19.745076
3	02	Factura de consumo	2021-01-19 11:22:19.7504	2021-01-19 11:22:19.7504
4	03	Nota de debito	2021-01-19 11:22:19.755222	2021-01-19 11:22:19.755222
5	04	Nota de credito	2021-01-19 11:22:19.759839	2021-01-19 11:22:19.759839
6	11	Comprobante de compras	2021-01-19 11:22:19.764605	2021-01-19 11:22:19.764605
7	12	Registro de unico ingreso	2021-01-19 11:22:19.769271	2021-01-19 11:22:19.769271
8	13	Comprobante para gastos menores	2021-01-19 11:22:19.773419	2021-01-19 11:22:19.773419
9	14	Comprobante de regimen especiales	2021-01-19 11:22:19.777658	2021-01-19 11:22:19.777658
10	15	Comprobante gubernamental	2021-01-19 11:22:19.782383	2021-01-19 11:22:19.782383
11	16	Comprobante para exportaciones	2021-01-19 11:22:19.78709	2021-01-19 11:22:19.78709
12	17	Comprobantes para pago al exterior	2021-01-19 11:22:19.791197	2021-01-19 11:22:19.791197
13	\N	Venta	2021-01-19 11:22:19.796161	2021-01-19 11:22:19.796161
14	\N	Compra	2021-01-19 11:22:19.800821	2021-01-19 11:22:19.800821
15	\N	Conduce	2021-01-19 11:22:19.805054	2021-01-19 11:22:19.805054
16	\N	Produccion	2021-01-19 11:22:19.809038	2021-01-19 11:22:19.809038
17	\N	Recibo_ingreso	2021-01-19 11:22:19.813402	2021-01-19 11:22:19.813402
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, provider, uid, encrypted_password, reset_password_token, reset_password_sent_at, allow_password_change, remember_created_at, confirmation_token, confirmed_at, confirmation_sent_at, unconfirmed_email, sign_in_count, current_sign_in_at, last_sign_in_at, current_sign_in_ip, last_sign_in_ip, imagen_id, nombre, usuario, apellido, sexo, telefono, email, fecha_nacimiento, estado, role, tokens, created_at, updated_at) FROM stdin;
1	email	mari_santos0515@hotmail.com	$2a$11$CHWpZJWsL32sb9kGXf409esbO6m1CER8.HuXcegxZ72gGcvvtlfEi	\N	\N	f	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	Mari	ADM	Santos	f	(829)292-8772	mari_santos0515@hotmail.com	1968-17-10	t	A	\N	2021-01-19 11:22:19.484223	2021-01-19 11:22:19.484223
2	email	admagroindustrialsrl@gmail.com	$2a$11$TO4Fy9zEDr4OLZ5fBJEhr.a9/GdKzCDNHwOukAISz790ZwEUvTG9y	\N	\N	f	\N	\N	\N	\N	\N	0	\N	\N	\N	\N	\N	ADM	adm01	 	i	(809) 573-0060	admagroindustrialsrl@gmail.com	2020-01-01	t	V	\N	2021-01-19 11:22:19.637258	2021-01-19 11:22:19.637258
\.


--
-- Data for Name: vehiculos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.vehiculos (id, user_id, marca, modelo, cantidad_viajes, created_at, updated_at, nombre_no_empleado, apellido_no_empleado, telefono_no_empleado, anio, estado) FROM stdin;
\.


--
-- Name: articulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.articulos_id_seq', 1, false);


--
-- Name: cabecera_conduces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cabecera_conduces_id_seq', 1, false);


--
-- Name: cabecera_facturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cabecera_facturas_id_seq', 1, false);


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.clientes_id_seq', 1, true);


--
-- Name: contenido_articulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contenido_articulos_id_seq', 1, false);


--
-- Name: cuadre_cajas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cuadre_cajas_id_seq', 1, false);


--
-- Name: detalle_conduces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.detalle_conduces_id_seq', 1, false);


--
-- Name: detalle_facturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.detalle_facturas_id_seq', 1, false);


--
-- Name: detalle_recibos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.detalle_recibos_id_seq', 1, false);


--
-- Name: detalles_produccion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.detalles_produccion_id_seq', 1, false);


--
-- Name: documentos_de_identidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documentos_de_identidad_id_seq', 2, true);


--
-- Name: formulas_productos_terminados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.formulas_productos_terminados_id_seq', 1, false);


--
-- Name: historico_producciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.historico_producciones_id_seq', 1, false);


--
-- Name: imagenes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.imagenes_id_seq', 1, false);


--
-- Name: incidencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.incidencias_id_seq', 1, false);


--
-- Name: mantenimiento_articulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mantenimiento_articulos_id_seq', 1, false);


--
-- Name: mantenimiento_formulas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mantenimiento_formulas_id_seq', 1, false);


--
-- Name: marcas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.marcas_id_seq', 1, true);


--
-- Name: modelos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.modelos_id_seq', 1, true);


--
-- Name: movimientos_inventarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.movimientos_inventarios_id_seq', 1, false);


--
-- Name: producciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.producciones_id_seq', 1, false);


--
-- Name: recibos_ingresos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recibos_ingresos_id_seq', 1, false);


--
-- Name: secuencia_comprobantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.secuencia_comprobantes_id_seq', 2, true);


--
-- Name: secuencia_facturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.secuencia_facturas_id_seq', 17, true);


--
-- Name: suplidores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.suplidores_id_seq', 1, false);


--
-- Name: tipo_articulos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tipo_articulos_id_seq', 4, true);


--
-- Name: tipo_facturas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tipo_facturas_id_seq', 17, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: vehiculos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.vehiculos_id_seq', 1, false);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: articulos articulos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT articulos_pkey PRIMARY KEY (id);


--
-- Name: cabecera_conduces cabecera_conduces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_conduces
    ADD CONSTRAINT cabecera_conduces_pkey PRIMARY KEY (id);


--
-- Name: cabecera_facturas cabecera_facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_facturas
    ADD CONSTRAINT cabecera_facturas_pkey PRIMARY KEY (id);


--
-- Name: clientes clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (id);


--
-- Name: contenido_articulos contenido_articulos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contenido_articulos
    ADD CONSTRAINT contenido_articulos_pkey PRIMARY KEY (id);


--
-- Name: cuadre_cajas cuadre_cajas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cuadre_cajas
    ADD CONSTRAINT cuadre_cajas_pkey PRIMARY KEY (id);


--
-- Name: detalle_conduces detalle_conduces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_conduces
    ADD CONSTRAINT detalle_conduces_pkey PRIMARY KEY (id);


--
-- Name: detalle_facturas detalle_facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_facturas
    ADD CONSTRAINT detalle_facturas_pkey PRIMARY KEY (id);


--
-- Name: detalle_recibos detalle_recibos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_recibos
    ADD CONSTRAINT detalle_recibos_pkey PRIMARY KEY (id);


--
-- Name: detalles_produccion detalles_produccion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_produccion
    ADD CONSTRAINT detalles_produccion_pkey PRIMARY KEY (id);


--
-- Name: documentos_de_identidad documentos_de_identidad_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_de_identidad
    ADD CONSTRAINT documentos_de_identidad_pkey PRIMARY KEY (id);


--
-- Name: formulas_productos_terminados formulas_productos_terminados_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.formulas_productos_terminados
    ADD CONSTRAINT formulas_productos_terminados_pkey PRIMARY KEY (id);


--
-- Name: historico_producciones historico_producciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historico_producciones
    ADD CONSTRAINT historico_producciones_pkey PRIMARY KEY (id);


--
-- Name: imagenes imagenes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.imagenes
    ADD CONSTRAINT imagenes_pkey PRIMARY KEY (id);


--
-- Name: incidencias incidencias_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.incidencias
    ADD CONSTRAINT incidencias_pkey PRIMARY KEY (id);


--
-- Name: mantenimiento_articulos mantenimiento_articulos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mantenimiento_articulos
    ADD CONSTRAINT mantenimiento_articulos_pkey PRIMARY KEY (id);


--
-- Name: mantenimiento_formulas mantenimiento_formulas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mantenimiento_formulas
    ADD CONSTRAINT mantenimiento_formulas_pkey PRIMARY KEY (id);


--
-- Name: marcas marcas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marcas
    ADD CONSTRAINT marcas_pkey PRIMARY KEY (id);


--
-- Name: modelos modelos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modelos
    ADD CONSTRAINT modelos_pkey PRIMARY KEY (id);


--
-- Name: movimientos_inventarios movimientos_inventarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_inventarios
    ADD CONSTRAINT movimientos_inventarios_pkey PRIMARY KEY (id);


--
-- Name: producciones producciones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.producciones
    ADD CONSTRAINT producciones_pkey PRIMARY KEY (id);


--
-- Name: recibos_ingresos recibos_ingresos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recibos_ingresos
    ADD CONSTRAINT recibos_ingresos_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: secuencia_comprobantes secuencia_comprobantes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secuencia_comprobantes
    ADD CONSTRAINT secuencia_comprobantes_pkey PRIMARY KEY (id);


--
-- Name: secuencia_facturas secuencia_facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secuencia_facturas
    ADD CONSTRAINT secuencia_facturas_pkey PRIMARY KEY (id);


--
-- Name: suplidores suplidores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suplidores
    ADD CONSTRAINT suplidores_pkey PRIMARY KEY (id);


--
-- Name: tipo_articulos tipo_articulos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipo_articulos
    ADD CONSTRAINT tipo_articulos_pkey PRIMARY KEY (id);


--
-- Name: tipo_facturas tipo_facturas_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tipo_facturas
    ADD CONSTRAINT tipo_facturas_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vehiculos vehiculos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehiculos
    ADD CONSTRAINT vehiculos_pkey PRIMARY KEY (id);


--
-- Name: index_articulos_on_imagen_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_articulos_on_imagen_id ON public.articulos USING btree (imagen_id);


--
-- Name: index_articulos_on_tipo_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_articulos_on_tipo_articulo_id ON public.articulos USING btree (tipo_articulo_id);


--
-- Name: index_cabecera_conduces_on_cliente_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cabecera_conduces_on_cliente_id ON public.cabecera_conduces USING btree (cliente_id);


--
-- Name: index_cabecera_conduces_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cabecera_conduces_on_user_id ON public.cabecera_conduces USING btree (user_id);


--
-- Name: index_cabecera_facturas_on_cliente_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cabecera_facturas_on_cliente_id ON public.cabecera_facturas USING btree (cliente_id);


--
-- Name: index_cabecera_facturas_on_suplidor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cabecera_facturas_on_suplidor_id ON public.cabecera_facturas USING btree (suplidor_id);


--
-- Name: index_cabecera_facturas_on_tipo_factura_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cabecera_facturas_on_tipo_factura_id ON public.cabecera_facturas USING btree (tipo_factura_id);


--
-- Name: index_cabecera_facturas_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cabecera_facturas_on_user_id ON public.cabecera_facturas USING btree (user_id);


--
-- Name: index_clientes_on_imagen_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_clientes_on_imagen_id ON public.clientes USING btree (imagen_id);


--
-- Name: index_contenido_articulos_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_contenido_articulos_on_articulo_id ON public.contenido_articulos USING btree (articulo_id);


--
-- Name: index_cuadre_cajas_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cuadre_cajas_on_user_id ON public.cuadre_cajas USING btree (user_id);


--
-- Name: index_detalle_conduces_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalle_conduces_on_articulo_id ON public.detalle_conduces USING btree (articulo_id);


--
-- Name: index_detalle_conduces_on_cabecera_conduce_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalle_conduces_on_cabecera_conduce_id ON public.detalle_conduces USING btree (cabecera_conduce_id);


--
-- Name: index_detalle_conduces_on_detalle_factura_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalle_conduces_on_detalle_factura_id ON public.detalle_conduces USING btree (detalle_factura_id);


--
-- Name: index_detalle_facturas_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalle_facturas_on_articulo_id ON public.detalle_facturas USING btree (articulo_id);


--
-- Name: index_detalle_facturas_on_cabecera_factura_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalle_facturas_on_cabecera_factura_id ON public.detalle_facturas USING btree (cabecera_factura_id);


--
-- Name: index_detalle_recibos_on_cabecera_factura_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalle_recibos_on_cabecera_factura_id ON public.detalle_recibos USING btree (cabecera_factura_id);


--
-- Name: index_detalle_recibos_on_recibos_ingreso_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalle_recibos_on_recibos_ingreso_id ON public.detalle_recibos USING btree (recibos_ingreso_id);


--
-- Name: index_detalles_produccion_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalles_produccion_on_articulo_id ON public.detalles_produccion USING btree (articulo_id);


--
-- Name: index_detalles_produccion_on_produccion_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_detalles_produccion_on_produccion_id ON public.detalles_produccion USING btree (produccion_id);


--
-- Name: index_documentos_de_identidad_on_cliente_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documentos_de_identidad_on_cliente_id ON public.documentos_de_identidad USING btree (cliente_id);


--
-- Name: index_documentos_de_identidad_on_suplidor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documentos_de_identidad_on_suplidor_id ON public.documentos_de_identidad USING btree (suplidor_id);


--
-- Name: index_documentos_de_identidad_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documentos_de_identidad_on_user_id ON public.documentos_de_identidad USING btree (user_id);


--
-- Name: index_formulas_productos_terminados_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_formulas_productos_terminados_on_articulo_id ON public.formulas_productos_terminados USING btree (articulo_id);


--
-- Name: index_historico_producciones_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_historico_producciones_on_articulo_id ON public.historico_producciones USING btree (articulo_id);


--
-- Name: index_historico_producciones_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_historico_producciones_on_user_id ON public.historico_producciones USING btree (user_id);


--
-- Name: index_mantenimiento_articulos_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_mantenimiento_articulos_on_articulo_id ON public.mantenimiento_articulos USING btree (articulo_id);


--
-- Name: index_mantenimiento_articulos_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_mantenimiento_articulos_on_user_id ON public.mantenimiento_articulos USING btree (user_id);


--
-- Name: index_modelos_on_marca_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_modelos_on_marca_id ON public.modelos USING btree (marca_id);


--
-- Name: index_movimientos_inventarios_on_articulo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_movimientos_inventarios_on_articulo_id ON public.movimientos_inventarios USING btree (articulo_id);


--
-- Name: index_movimientos_inventarios_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_movimientos_inventarios_on_user_id ON public.movimientos_inventarios USING btree (user_id);


--
-- Name: index_producciones_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_producciones_on_user_id ON public.producciones USING btree (user_id);


--
-- Name: index_recibos_ingresos_on_cliente_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recibos_ingresos_on_cliente_id ON public.recibos_ingresos USING btree (cliente_id);


--
-- Name: index_recibos_ingresos_on_tipo_factura_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recibos_ingresos_on_tipo_factura_id ON public.recibos_ingresos USING btree (tipo_factura_id);


--
-- Name: index_recibos_ingresos_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recibos_ingresos_on_user_id ON public.recibos_ingresos USING btree (user_id);


--
-- Name: index_recibos_ingresos_on_vehiculo_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recibos_ingresos_on_vehiculo_id ON public.recibos_ingresos USING btree (vehiculo_id);


--
-- Name: index_secuencia_comprobantes_on_tipo_factura_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_secuencia_comprobantes_on_tipo_factura_id ON public.secuencia_comprobantes USING btree (tipo_factura_id);


--
-- Name: index_secuencia_facturas_on_tipo_factura_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_secuencia_facturas_on_tipo_factura_id ON public.secuencia_facturas USING btree (tipo_factura_id);


--
-- Name: index_users_on_confirmation_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_confirmation_token ON public.users USING btree (confirmation_token);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_imagen_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_imagen_id ON public.users USING btree (imagen_id);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: index_users_on_uid_and_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_users_on_uid_and_provider ON public.users USING btree (uid, provider);


--
-- Name: index_vehiculos_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_vehiculos_on_user_id ON public.vehiculos USING btree (user_id);


--
-- Name: cabecera_facturas fk_rails_05d202355d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_facturas
    ADD CONSTRAINT fk_rails_05d202355d FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: secuencia_facturas fk_rails_11575bbb1f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secuencia_facturas
    ADD CONSTRAINT fk_rails_11575bbb1f FOREIGN KEY (tipo_factura_id) REFERENCES public.tipo_facturas(id);


--
-- Name: documentos_de_identidad fk_rails_16a2c957c8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_de_identidad
    ADD CONSTRAINT fk_rails_16a2c957c8 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: mantenimiento_articulos fk_rails_24ec1a088e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mantenimiento_articulos
    ADD CONSTRAINT fk_rails_24ec1a088e FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: detalle_conduces fk_rails_285e65bec9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_conduces
    ADD CONSTRAINT fk_rails_285e65bec9 FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: historico_producciones fk_rails_34a7e84647; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historico_producciones
    ADD CONSTRAINT fk_rails_34a7e84647 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: detalle_conduces fk_rails_363c43ebe0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_conduces
    ADD CONSTRAINT fk_rails_363c43ebe0 FOREIGN KEY (detalle_factura_id) REFERENCES public.detalle_facturas(id);


--
-- Name: detalle_facturas fk_rails_36bda867ba; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_facturas
    ADD CONSTRAINT fk_rails_36bda867ba FOREIGN KEY (cabecera_factura_id) REFERENCES public.cabecera_facturas(id);


--
-- Name: cuadre_cajas fk_rails_397a5234c6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cuadre_cajas
    ADD CONSTRAINT fk_rails_397a5234c6 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: producciones fk_rails_399ea5f3bd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.producciones
    ADD CONSTRAINT fk_rails_399ea5f3bd FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: articulos fk_rails_3c196715e3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT fk_rails_3c196715e3 FOREIGN KEY (imagen_id) REFERENCES public.imagenes(id);


--
-- Name: movimientos_inventarios fk_rails_3e227c1179; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_inventarios
    ADD CONSTRAINT fk_rails_3e227c1179 FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: movimientos_inventarios fk_rails_3f65de427a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.movimientos_inventarios
    ADD CONSTRAINT fk_rails_3f65de427a FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cabecera_facturas fk_rails_4a1540b806; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_facturas
    ADD CONSTRAINT fk_rails_4a1540b806 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: cabecera_facturas fk_rails_5d2c0bf873; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_facturas
    ADD CONSTRAINT fk_rails_5d2c0bf873 FOREIGN KEY (tipo_factura_id) REFERENCES public.tipo_facturas(id);


--
-- Name: cabecera_facturas fk_rails_636ab011e4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_facturas
    ADD CONSTRAINT fk_rails_636ab011e4 FOREIGN KEY (suplidor_id) REFERENCES public.suplidores(id);


--
-- Name: secuencia_comprobantes fk_rails_6c31942520; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.secuencia_comprobantes
    ADD CONSTRAINT fk_rails_6c31942520 FOREIGN KEY (tipo_factura_id) REFERENCES public.tipo_facturas(id);


--
-- Name: recibos_ingresos fk_rails_75f99e805c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recibos_ingresos
    ADD CONSTRAINT fk_rails_75f99e805c FOREIGN KEY (tipo_factura_id) REFERENCES public.tipo_facturas(id);


--
-- Name: documentos_de_identidad fk_rails_773690865d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_de_identidad
    ADD CONSTRAINT fk_rails_773690865d FOREIGN KEY (suplidor_id) REFERENCES public.suplidores(id);


--
-- Name: detalle_recibos fk_rails_7ea53c0731; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_recibos
    ADD CONSTRAINT fk_rails_7ea53c0731 FOREIGN KEY (recibos_ingreso_id) REFERENCES public.recibos_ingresos(id);


--
-- Name: recibos_ingresos fk_rails_8204330177; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recibos_ingresos
    ADD CONSTRAINT fk_rails_8204330177 FOREIGN KEY (vehiculo_id) REFERENCES public.vehiculos(id);


--
-- Name: detalles_produccion fk_rails_8327bd6cc8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_produccion
    ADD CONSTRAINT fk_rails_8327bd6cc8 FOREIGN KEY (produccion_id) REFERENCES public.producciones(id);


--
-- Name: detalle_conduces fk_rails_86fe605c5b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_conduces
    ADD CONSTRAINT fk_rails_86fe605c5b FOREIGN KEY (cabecera_conduce_id) REFERENCES public.cabecera_conduces(id);


--
-- Name: clientes fk_rails_8b5f8e8dda; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT fk_rails_8b5f8e8dda FOREIGN KEY (imagen_id) REFERENCES public.imagenes(id);


--
-- Name: historico_producciones fk_rails_988c6d0444; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historico_producciones
    ADD CONSTRAINT fk_rails_988c6d0444 FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: articulos fk_rails_9e48039b77; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.articulos
    ADD CONSTRAINT fk_rails_9e48039b77 FOREIGN KEY (tipo_articulo_id) REFERENCES public.tipo_articulos(id);


--
-- Name: cabecera_conduces fk_rails_b2e4bc527c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_conduces
    ADD CONSTRAINT fk_rails_b2e4bc527c FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: vehiculos fk_rails_bae005eafd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vehiculos
    ADD CONSTRAINT fk_rails_bae005eafd FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recibos_ingresos fk_rails_bd2009c5e1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recibos_ingresos
    ADD CONSTRAINT fk_rails_bd2009c5e1 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recibos_ingresos fk_rails_be29ea764a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recibos_ingresos
    ADD CONSTRAINT fk_rails_be29ea764a FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: detalle_recibos fk_rails_bf3aa82ced; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_recibos
    ADD CONSTRAINT fk_rails_bf3aa82ced FOREIGN KEY (cabecera_factura_id) REFERENCES public.cabecera_facturas(id);


--
-- Name: mantenimiento_articulos fk_rails_c0485e9f74; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mantenimiento_articulos
    ADD CONSTRAINT fk_rails_c0485e9f74 FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: users fk_rails_c382f94dbc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_rails_c382f94dbc FOREIGN KEY (imagen_id) REFERENCES public.imagenes(id);


--
-- Name: detalles_produccion fk_rails_c53d1194ba; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalles_produccion
    ADD CONSTRAINT fk_rails_c53d1194ba FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: contenido_articulos fk_rails_cbd15b6432; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contenido_articulos
    ADD CONSTRAINT fk_rails_cbd15b6432 FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: modelos fk_rails_d02b48457e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.modelos
    ADD CONSTRAINT fk_rails_d02b48457e FOREIGN KEY (marca_id) REFERENCES public.marcas(id);


--
-- Name: cabecera_conduces fk_rails_dc6bc0c1ac; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cabecera_conduces
    ADD CONSTRAINT fk_rails_dc6bc0c1ac FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: formulas_productos_terminados fk_rails_e4ccfdfc90; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.formulas_productos_terminados
    ADD CONSTRAINT fk_rails_e4ccfdfc90 FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- Name: documentos_de_identidad fk_rails_e84f87c22b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documentos_de_identidad
    ADD CONSTRAINT fk_rails_e84f87c22b FOREIGN KEY (cliente_id) REFERENCES public.clientes(id);


--
-- Name: detalle_facturas fk_rails_fd71927ed6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.detalle_facturas
    ADD CONSTRAINT fk_rails_fd71927ed6 FOREIGN KEY (articulo_id) REFERENCES public.articulos(id);


--
-- PostgreSQL database dump complete
--

